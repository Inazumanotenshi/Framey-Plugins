// SteamGridDB for Framey: pick Steam artwork from SteamGridDB inside the VR panel.
const ID = "steamgriddb";
const CODES = ["de", "en", "fr", "es", "it", "pt"];
const NAMES = { de: "Deutsch", en: "English", fr: "Français", es: "Español", it: "Italiano", pt: "Português" };

// Translations. Missing keys fall back to English. To add a language: add its code to
// CODES and NAMES above (and to LANGS in backend.py), then add a block here.
const LANGS = {
  en: {
    installed: "Installed games", noGames: "No installed games found.", reload: "Reload",
    appidPh: "Steam app ID", open: "Open", back: "‹ Back", language: "Language",
    keyTitle: "API key", keyText: "SteamGridDB needs a free API key (steamgriddb.com → profile → Preferences → API).",
    keyPh: "Paste API key", keySave: "Save", keyChange: "Change API key",
    keyFile: "If typing does not work here: save the key over SSH to ~/.config/framey/steamgriddb.json as {\"api_key\": \"...\"}.",
    loading: "Loading …", more: "Load more", empty: "No images found.", applying: "Applying …",
    done: "Applied, but Steam may only show it after restarting SteamVR (instant refresh unavailable).", doneLive: "Applied and refreshed right away.", diagBtn: "Check Steam interface", diagHint: "Shows whether instant artwork refresh is available. Handy for bug reports.", failed: "Failed: ",
    reset: "Remove custom artwork", resetDone: "Reset.", custom: "Custom artwork active",
    kinds: { grid_p: "Portrait", grid_w: "Wide", hero: "Hero", logo: "Logo", icon: "Icon" },
    err: {
      no_key: "No API key saved.", bad_key: "Invalid API key.", bad_key_format: "That key looks invalid.",
      not_found: "Nothing on SteamGridDB for this game.", no_steam: "Steam folder not found.",
      no_user: "No Steam user folder found.", timeout: "Timed out.", network: "Network error.",
      io: "File error.", bad_appid: "Invalid app ID.", too_large: "Image too large.",
      bad_image: "Unsupported image format.", bad_data: "Unexpected response.", generic: "Unknown error.",
    },
  },
  de: {
    installed: "Installierte Spiele", noGames: "Keine installierten Spiele gefunden.", reload: "Neu laden",
    appidPh: "Steam-App-ID", open: "Öffnen", back: "‹ Zurück", language: "Sprache",
    keyTitle: "API-Key", keyText: "Für SteamGridDB brauchst du einen kostenlosen API-Key (steamgriddb.com → Profil → Preferences → API).",
    keyPh: "API-Key einfügen", keySave: "Speichern", keyChange: "API-Key ändern",
    keyFile: "Falls die Eingabe hier nicht geht: Key per SSH in ~/.config/framey/steamgriddb.json als {\"api_key\": \"...\"} speichern.",
    loading: "Lade …", more: "Mehr laden", empty: "Keine Bilder gefunden.", applying: "Wird gesetzt …",
    done: "Gesetzt. Steam zeigt es eventuell erst nach einem SteamVR-Neustart (Sofort-Aktualisierung nicht verfügbar).", doneLive: "Gesetzt und sofort aktualisiert.", diagBtn: "Steam-Schnittstelle prüfen", diagHint: "Zeigt, ob die Sofort-Aktualisierung verfügbar ist. Nützlich für Fehlerberichte.", failed: "Fehlgeschlagen: ",
    reset: "Eigenes Artwork entfernen", resetDone: "Zurückgesetzt.", custom: "Eigenes Artwork aktiv",
    kinds: { grid_p: "Cover hoch", grid_w: "Cover breit", hero: "Hero", logo: "Logo", icon: "Icon" },
    err: {
      no_key: "Kein API-Key gespeichert.", bad_key: "API-Key ungültig.", bad_key_format: "Der Key sieht ungültig aus.",
      not_found: "Für dieses Spiel gibt es nichts bei SteamGridDB.", no_steam: "Steam-Ordner nicht gefunden.",
      no_user: "Kein Steam-Benutzerordner gefunden.", timeout: "Zeitüberschreitung.", network: "Netzwerkfehler.",
      io: "Dateifehler.", bad_appid: "Ungültige App-ID.", too_large: "Bild zu groß.",
      bad_image: "Bildformat nicht unterstützt.", bad_data: "Unerwartete Antwort.", generic: "Unbekannter Fehler.",
    },
  },
  fr: {
    installed: "Jeux installés", noGames: "Aucun jeu installé trouvé.", reload: "Recharger",
    appidPh: "ID d'application Steam", open: "Ouvrir", back: "‹ Retour", language: "Langue",
    keyTitle: "Clé API", keyText: "SteamGridDB nécessite une clé API gratuite (steamgriddb.com → profil → Preferences → API).",
    keyPh: "Coller la clé API", keySave: "Enregistrer", keyChange: "Changer la clé API",
    keyFile: "Si la saisie ne fonctionne pas ici : enregistrez la clé via SSH dans ~/.config/framey/steamgriddb.json sous la forme {\"api_key\": \"...\"}.",
    loading: "Chargement …", more: "Charger plus", empty: "Aucune image trouvée.", applying: "Application …",
    done: "Appliqué, mais Steam ne l'affichera peut-être qu'après un redémarrage de SteamVR (actualisation immédiate indisponible).", doneLive: "Appliqué et actualisé immédiatement.", diagBtn: "Vérifier l'interface Steam", diagHint: "Indique si l'actualisation immédiate est disponible. Utile pour les rapports de bug.", failed: "Échec : ",
    reset: "Supprimer l'illustration personnalisée", resetDone: "Réinitialisé.", custom: "Illustration personnalisée active",
    kinds: { grid_p: "Portrait", grid_w: "Large", hero: "Hero", logo: "Logo", icon: "Icône" },
    err: {
      no_key: "Aucune clé API enregistrée.", bad_key: "Clé API invalide.", bad_key_format: "Cette clé semble invalide.",
      not_found: "Rien sur SteamGridDB pour ce jeu.", no_steam: "Dossier Steam introuvable.",
      no_user: "Aucun dossier utilisateur Steam trouvé.", timeout: "Délai dépassé.", network: "Erreur réseau.",
      io: "Erreur de fichier.", bad_appid: "ID d'application invalide.", too_large: "Image trop grande.",
      bad_image: "Format d'image non pris en charge.", bad_data: "Réponse inattendue.", generic: "Erreur inconnue.",
    },
  },
  es: {
    installed: "Juegos instalados", noGames: "No se encontraron juegos instalados.", reload: "Recargar",
    appidPh: "ID de aplicación de Steam", open: "Abrir", back: "‹ Atrás", language: "Idioma",
    keyTitle: "Clave de API", keyText: "SteamGridDB necesita una clave de API gratuita (steamgriddb.com → perfil → Preferences → API).",
    keyPh: "Pegar clave de API", keySave: "Guardar", keyChange: "Cambiar clave de API",
    keyFile: "Si aquí no se puede escribir: guarda la clave por SSH en ~/.config/framey/steamgriddb.json como {\"api_key\": \"...\"}.",
    loading: "Cargando …", more: "Cargar más", empty: "No se encontraron imágenes.", applying: "Aplicando …",
    done: "Aplicado, pero Steam quizá solo lo muestre tras reiniciar SteamVR (actualización instantánea no disponible).", doneLive: "Aplicado y actualizado al instante.", diagBtn: "Comprobar la interfaz de Steam", diagHint: "Muestra si la actualización instantánea está disponible. Útil para informes de errores.", failed: "Error: ",
    reset: "Quitar arte personalizado", resetDone: "Restablecido.", custom: "Arte personalizado activo",
    kinds: { grid_p: "Vertical", grid_w: "Horizontal", hero: "Hero", logo: "Logo", icon: "Icono" },
    err: {
      no_key: "No hay ninguna clave de API guardada.", bad_key: "Clave de API no válida.", bad_key_format: "La clave parece no válida.",
      not_found: "No hay nada en SteamGridDB para este juego.", no_steam: "No se encontró la carpeta de Steam.",
      no_user: "No se encontró ninguna carpeta de usuario de Steam.", timeout: "Tiempo de espera agotado.", network: "Error de red.",
      io: "Error de archivo.", bad_appid: "ID de aplicación no válida.", too_large: "Imagen demasiado grande.",
      bad_image: "Formato de imagen no compatible.", bad_data: "Respuesta inesperada.", generic: "Error desconocido.",
    },
  },
  it: {
    installed: "Giochi installati", noGames: "Nessun gioco installato trovato.", reload: "Ricarica",
    appidPh: "ID app Steam", open: "Apri", back: "‹ Indietro", language: "Lingua",
    keyTitle: "Chiave API", keyText: "SteamGridDB richiede una chiave API gratuita (steamgriddb.com → profilo → Preferences → API).",
    keyPh: "Incolla la chiave API", keySave: "Salva", keyChange: "Cambia chiave API",
    keyFile: "Se qui non puoi digitare: salva la chiave via SSH in ~/.config/framey/steamgriddb.json come {\"api_key\": \"...\"}.",
    loading: "Caricamento …", more: "Carica altro", empty: "Nessuna immagine trovata.", applying: "Applicazione …",
    done: "Applicato, ma Steam potrebbe mostrarlo solo dopo il riavvio di SteamVR (aggiornamento immediato non disponibile).", doneLive: "Applicato e aggiornato subito.", diagBtn: "Controlla l'interfaccia di Steam", diagHint: "Mostra se l'aggiornamento immediato è disponibile. Utile per segnalare errori.", failed: "Errore: ",
    reset: "Rimuovi artwork personalizzato", resetDone: "Ripristinato.", custom: "Artwork personalizzato attivo",
    kinds: { grid_p: "Verticale", grid_w: "Orizzontale", hero: "Hero", logo: "Logo", icon: "Icona" },
    err: {
      no_key: "Nessuna chiave API salvata.", bad_key: "Chiave API non valida.", bad_key_format: "La chiave sembra non valida.",
      not_found: "Niente su SteamGridDB per questo gioco.", no_steam: "Cartella di Steam non trovata.",
      no_user: "Nessuna cartella utente di Steam trovata.", timeout: "Tempo scaduto.", network: "Errore di rete.",
      io: "Errore file.", bad_appid: "ID app non valido.", too_large: "Immagine troppo grande.",
      bad_image: "Formato immagine non supportato.", bad_data: "Risposta imprevista.", generic: "Errore sconosciuto.",
    },
  },
  pt: {
    installed: "Jogos instalados", noGames: "Nenhum jogo instalado encontrado.", reload: "Recarregar",
    appidPh: "ID do app Steam", open: "Abrir", back: "‹ Voltar", language: "Idioma",
    keyTitle: "Chave de API", keyText: "O SteamGridDB precisa de uma chave de API gratuita (steamgriddb.com → perfil → Preferences → API).",
    keyPh: "Colar chave de API", keySave: "Salvar", keyChange: "Alterar chave de API",
    keyFile: "Se não for possível digitar aqui: salve a chave via SSH em ~/.config/framey/steamgriddb.json como {\"api_key\": \"...\"}.",
    loading: "Carregando …", more: "Carregar mais", empty: "Nenhuma imagem encontrada.", applying: "Aplicando …",
    done: "Aplicado, mas o Steam talvez só mostre após reiniciar o SteamVR (atualização imediata indisponível).", doneLive: "Aplicado e atualizado na hora.", diagBtn: "Verificar a interface do Steam", diagHint: "Mostra se a atualização imediata está disponível. Útil para relatar erros.", failed: "Falha: ",
    reset: "Remover arte personalizada", resetDone: "Redefinido.", custom: "Arte personalizada ativa",
    kinds: { grid_p: "Vertical", grid_w: "Horizontal", hero: "Hero", logo: "Logo", icon: "Ícone" },
    err: {
      no_key: "Nenhuma chave de API salva.", bad_key: "Chave de API inválida.", bad_key_format: "A chave parece inválida.",
      not_found: "Não há nada no SteamGridDB para este jogo.", no_steam: "Pasta do Steam não encontrada.",
      no_user: "Nenhuma pasta de usuário do Steam encontrada.", timeout: "Tempo esgotado.", network: "Erro de rede.",
      io: "Erro de arquivo.", bad_appid: "ID de app inválido.", too_large: "Imagem grande demais.",
      bad_image: "Formato de imagem não suportado.", bad_data: "Resposta inesperada.", generic: "Erro desconhecido.",
    },
  },
};

// Texts for the search-by-name feature (merged into S by build(); English is the fallback).
const MORE = {
  "en": {
    "unknownTitle": "Unknown apps",
    "unknownName": "Unknown",
    "unknownHint": "SteamGridDB doesn't know these apps. Tap one and search by name.",
    "searchTitle": "Find the game on SteamGridDB",
    "searchHint": "Enter the game's name. Your choice is remembered for this app.",
    "searchPh": "Game name",
    "searchBtn": "Search",
    "searchOther": "Search by name",
    "suggestions": "Suggestions",
    "searchedFor": "Searched for",
    "noMatches": "Nothing found for this name.",
    "searching": "Searching …",
    "hide": "Hide",
    "mappedTo": "Matched to",
    "forget": "Remove match",
    "forgotDone": "Match removed.",
    "removeUnknown": "Remove from list",
    "assigned": "Matched."
  },
  "de": {
    "unknownTitle": "Unbekannte Apps",
    "unknownName": "Unbekannt",
    "unknownHint": "SteamGridDB kennt diese Apps nicht. Antippen und per Namen suchen.",
    "searchTitle": "Spiel bei SteamGridDB suchen",
    "searchHint": "Gib den Namen des Spiels ein. Deine Auswahl wird für diese App gespeichert.",
    "searchPh": "Spielname",
    "searchBtn": "Suchen",
    "searchOther": "Nach Namen suchen",
    "suggestions": "Vorschläge",
    "searchedFor": "Gesucht nach",
    "noMatches": "Zu diesem Namen wurde nichts gefunden.",
    "searching": "Suche …",
    "hide": "Ausblenden",
    "mappedTo": "Zugeordnet zu",
    "forget": "Zuordnung entfernen",
    "forgotDone": "Zuordnung entfernt.",
    "removeUnknown": "Aus Liste entfernen",
    "assigned": "Zugeordnet."
  },
  "fr": {
    "unknownTitle": "Applications inconnues",
    "unknownName": "Inconnue",
    "unknownHint": "SteamGridDB ne connaît pas ces applications. Touchez-en une et cherchez par nom.",
    "searchTitle": "Trouver le jeu sur SteamGridDB",
    "searchHint": "Saisissez le nom du jeu. Votre choix est mémorisé pour cette application.",
    "searchPh": "Nom du jeu",
    "searchBtn": "Rechercher",
    "searchOther": "Rechercher par nom",
    "suggestions": "Suggestions",
    "searchedFor": "Recherché",
    "noMatches": "Rien trouvé pour ce nom.",
    "searching": "Recherche …",
    "hide": "Masquer",
    "mappedTo": "Associé à",
    "forget": "Supprimer l'association",
    "forgotDone": "Association supprimée.",
    "removeUnknown": "Retirer de la liste",
    "assigned": "Associé."
  },
  "es": {
    "unknownTitle": "Aplicaciones desconocidas",
    "unknownName": "Desconocida",
    "unknownHint": "SteamGridDB no conoce estas apps. Toca una y busca por nombre.",
    "searchTitle": "Buscar el juego en SteamGridDB",
    "searchHint": "Escribe el nombre del juego. Tu elección se guarda para esta app.",
    "searchPh": "Nombre del juego",
    "searchBtn": "Buscar",
    "searchOther": "Buscar por nombre",
    "suggestions": "Sugerencias",
    "searchedFor": "Buscado",
    "noMatches": "No se encontró nada con ese nombre.",
    "searching": "Buscando …",
    "hide": "Ocultar",
    "mappedTo": "Asignado a",
    "forget": "Quitar asignación",
    "forgotDone": "Asignación quitada.",
    "removeUnknown": "Quitar de la lista",
    "assigned": "Asignado."
  },
  "it": {
    "unknownTitle": "App sconosciute",
    "unknownName": "Sconosciuta",
    "unknownHint": "SteamGridDB non conosce queste app. Toccane una e cerca per nome.",
    "searchTitle": "Cerca il gioco su SteamGridDB",
    "searchHint": "Inserisci il nome del gioco. La tua scelta viene salvata per questa app.",
    "searchPh": "Nome del gioco",
    "searchBtn": "Cerca",
    "searchOther": "Cerca per nome",
    "suggestions": "Suggerimenti",
    "searchedFor": "Cercato",
    "noMatches": "Nessun risultato per questo nome.",
    "searching": "Ricerca …",
    "hide": "Nascondi",
    "mappedTo": "Assegnato a",
    "forget": "Rimuovi associazione",
    "forgotDone": "Associazione rimossa.",
    "removeUnknown": "Rimuovi dall'elenco",
    "assigned": "Assegnato."
  },
  "pt": {
    "unknownTitle": "Apps desconhecidos",
    "unknownName": "Desconhecido",
    "unknownHint": "O SteamGridDB não conhece estes apps. Toque em um e procure pelo nome.",
    "searchTitle": "Procurar o jogo no SteamGridDB",
    "searchHint": "Digite o nome do jogo. Sua escolha fica salva para este app.",
    "searchPh": "Nome do jogo",
    "searchBtn": "Procurar",
    "searchOther": "Procurar por nome",
    "suggestions": "Sugestões",
    "searchedFor": "Procurado",
    "noMatches": "Nada encontrado para esse nome.",
    "searching": "Procurando …",
    "hide": "Ocultar",
    "mappedTo": "Associado a",
    "forget": "Remover atribuição",
    "forgotDone": "Atribuição removida.",
    "removeUnknown": "Remover da lista",
    "assigned": "Atribuído."
  }
};

function pick(code) {
  const c = String(code || "").toLowerCase().slice(0, 2);
  return CODES.indexOf(c) >= 0 ? c : "en";
}

function build(code) {
  const b = LANGS.en, l = LANGS[code] || {};
  const o = Object.assign({}, b, MORE.en, l, MORE[code] || {});
  o.kinds = Object.assign({}, b.kinds, l.kinds);
  o.err = Object.assign({}, b.err, l.err);
  return o;
}

let lang = pick(navigator.language);
let S = build(lang);

const KINDS = ["grid_p", "grid_w", "hero", "logo", "icon"];
const SIZE = { grid_p: [150, 225], grid_w: [270, 128], hero: [340, 110], logo: [230, 110], icon: [96, 96] };

const st = {
  status: null, games: null, loading: false, homeErr: "", editKey: false,
  appid: null, name: "", kind: "grid_p", items: null, page: 0, more: false,
  has: {}, busy: false, req: 0, listErr: "", diag: null, why: null,
  localName: "", unknown: false, mapped: null, srReq: 0, dirtyHome: false,
  sr: { open: false, term: "", results: null, used: "", loading: false, err: "" },
};
let root = null;

function errText(e) {
  const m = String((e && e.message) || e);
  if (S.err[m]) return S.err[m];
  if (m.indexOf("bad_data") === 0) return S.err.bad_data + " (" + m.slice(9) + ")";
  return m.indexOf("http_") === 0 ? "HTTP " + m.slice(5) : S.err.generic;
}

function setLang(code, save) {
  lang = code;
  S = build(code);
  if (save) api("set_lang", { lang: code }).catch(function () {});
  draw();
}

function api(method, arg) {
  return Promise.race([
    Framey.call(ID, method, arg),
    new Promise(function (_, rej) { setTimeout(function () { rej(new Error("timeout")); }, 60000); }),
  ]).then(function (r) {
    if (r && r.error) throw new Error(r.error);
    return r;
  });
}

function field(ph) {
  const i = document.createElement("input");
  i.setAttribute("data-fy", "1");
  i.placeholder = ph;
  i.style.cssText = "width:100%;box-sizing:border-box;padding:16px;font-size:22px;border-radius:12px;" +
    "border:2px solid #4a5560;background:#1b2024;color:#fff;margin:8px 0;";
  return i;
}

const BTN = "padding:14px 22px;font-size:22px;border-radius:12px;background:#3d6fd6;color:#fff;margin:6px 0;";
const BTN_DIM = "padding:14px 22px;font-size:22px;border-radius:12px;background:#3a434b;color:#fff;margin:6px 0;";

// ---- animations and game icons ----------------------------------------------

const ANIM_CSS = "@keyframes fyPop{0%{transform:scale(1)}40%{transform:scale(1.2)}100%{transform:scale(1)}}" +
  "@keyframes fySpin{to{transform:rotate(360deg)}}" +
  "@keyframes fyFade{0%{opacity:0}15%{opacity:1}75%{opacity:1}100%{opacity:0}}" +
  "@keyframes fyIn{from{opacity:0;transform:scale(.7)}to{opacity:1;transform:scale(1)}}";
const iconCache = {};
const iconWait = {};
let iconQ = [], iconBusy = false;

function pumpIcons() {
  if (iconBusy || !iconQ.length) return;
  iconBusy = true;
  const batch = iconQ.splice(0, 8);
  api("icons", { appids: batch }).then(function (r) {
    batch.forEach(function (a) {
      const v = (r.icons && typeof r.icons[a] === "string") ? r.icons[a] : "";
      iconCache[a] = v;
      (iconWait[a] || []).forEach(function (f) { f(v); });
      delete iconWait[a];
    });
  }).catch(function () {
    batch.forEach(function (a) { delete iconWait[a]; });
  }).then(function () {
    iconBusy = false;
    pumpIcons();
  });
}

function iconEl(appid, size, pop) {
  const box = Framey.el("flex:none;width:" + size + "px;height:" + size + "px;border-radius:" + Math.round(size / 5) +
    "px;background:#14181c;overflow:hidden;" + (pop ? "animation:fyPop .6s ease;" : ""), "");
  const put = function (src, cached) {
    box.textContent = "";                 // removes the loading ring
    if (!src) return;
    const im = document.createElement("img");
    im.style.cssText = "display:block;width:100%;height:100%;object-fit:cover;" + (cached ? "" : "animation:fyIn .35s ease;");
    im.src = src;
    box.appendChild(im);
  };
  if (iconCache[appid] !== undefined) {
    put(iconCache[appid], true);
  } else {
    const ring = Math.max(14, Math.round(size / 3));
    box.appendChild(Framey.el("position:relative;left:50%;top:50%;margin:-" + Math.round(ring / 2) + "px 0 0 -" + Math.round(ring / 2) +
      "px;width:" + ring + "px;height:" + ring + "px;border-radius:50%;border:3px solid #3d6fd6;border-top-color:transparent;box-sizing:border-box;animation:fySpin .8s linear infinite;", ""));
    (iconWait[appid] = iconWait[appid] || []).push(put);
    if (iconQ.indexOf(appid) < 0) iconQ.push(appid);
    pumpIcons();
  }
  return box;
}

function overlay(kind) {
  const o = Framey.el("position:absolute;left:0;top:0;right:0;bottom:0;display:flex;align-items:center;justify-content:center;" +
    "border-radius:10px;pointer-events:none;" + (kind === "busy" ? "background:rgba(10,14,18,.6);" : "background:rgba(40,160,90,.35);animation:fyFade 1.5s ease forwards;"), "");
  if (kind === "busy") {
    o.appendChild(Framey.el("width:34px;height:34px;border-radius:50%;border:4px solid #3d6fd6;border-top-color:transparent;animation:fySpin .8s linear infinite;", ""));
  } else {
    o.appendChild(Framey.el("width:46px;height:46px;border-radius:50%;background:#2fb36b;color:#fff;font-size:30px;line-height:46px;text-align:center;animation:fyIn .35s ease;", "✓"));
  }
  return o;
}

function draw() {
  if (!root) return;
  root.textContent = "";
  const sty = document.createElement("style");
  sty.textContent = ANIM_CSS;
  root.appendChild(sty);
  root.appendChild(st.appid ? detailView() : homeView());
}

// ---- home -----------------------------------------------------------------

function loadHome() {
  if (st.loading) return;
  st.loading = true;
  Promise.all([api("status"), api("games")]).then(function (r) {
    st.status = r[0];
    st.games = r[1].games || [];
    st.homeErr = "";
    if (r[0].lang && r[0].lang !== lang) { lang = r[0].lang; S = build(lang); }
  }).catch(function (e) {
    st.status = {};
    st.games = [];
    st.homeErr = errText(e);
  }).then(function () {
    st.loading = false;
    draw();
  });
}

function homeView() {
  const w = Framey.el("padding:8px;color:#e6e9ec;");
  w.appendChild(Framey.el("font-size:32px;font-weight:600;margin-bottom:14px;", "SteamGridDB"));
  if (st.status === null) {
    loadHome();
    w.appendChild(Framey.el("font-size:22px;color:#9aa5af;", S.loading));
    return w;
  }
  if (st.homeErr) w.appendChild(Framey.el("font-size:22px;color:#ff8a80;margin-bottom:10px;", st.homeErr));

  if (!st.status.has_key || st.editKey) {
    w.appendChild(Framey.el("font-size:26px;font-weight:600;margin:6px 0;", S.keyTitle));
    w.appendChild(Framey.el("font-size:20px;color:#9aa5af;", S.keyText));
    const inp = field(S.keyPh);
    w.appendChild(inp);
    w.appendChild(Framey.button(S.keySave, BTN, function () {
      api("set_key", { key: inp.value }).then(function () {
        st.status.has_key = true;
        st.editKey = false;
        draw();
      }).catch(function (e) { Framey.toast(S.failed + errText(e), 4000); });
    }));
    w.appendChild(Framey.el("font-size:17px;color:#7d8791;margin-top:6px;", S.keyFile));
  } else {
    w.appendChild(Framey.button(S.keyChange, BTN_DIM, function () { st.editKey = true; draw(); }));
  }

  w.appendChild(Framey.el("font-size:26px;font-weight:600;margin:18px 0 6px;", S.appidPh));
  const idInp = field(S.appidPh);
  idInp.setAttribute("inputmode", "numeric");
  w.appendChild(idInp);
  w.appendChild(Framey.button(S.open, BTN, function () {
    const v = idInp.value.trim();
    if (/^[0-9]{1,10}$/.test(v)) select(v, "", false);
  }));

  const known = st.games.filter(function (g) { return !g.unknown; });
  const unknown = st.games.filter(function (g) { return g.unknown; });
  const addRow = function (g) {
    const row = Framey.el("display:flex;align-items:center;gap:16px;padding:12px 20px;margin:8px 0;border-radius:14px;background:" +
      (g.unknown ? "#2f2a38" : "#2a3138") + ";cursor:pointer;", "");
    row.appendChild(iconEl(g.appid, 56, false));
    const txt = Framey.el("flex:1;min-width:0;", "");
    txt.appendChild(Framey.el("font-size:24px;", g.name || S.unknownName));
    txt.appendChild(Framey.el("font-size:16px;color:#7d8791;", String(g.appid)));
    row.appendChild(txt);
    row.onclick = function () { select(g.appid, g.name, g.unknown); };
    w.appendChild(row);
  };
  w.appendChild(Framey.el("font-size:26px;font-weight:600;margin:18px 0 6px;", S.installed));
  if (!known.length && !unknown.length) w.appendChild(Framey.el("font-size:20px;color:#9aa5af;", S.noGames));
  known.forEach(addRow);
  if (unknown.length) {
    w.appendChild(Framey.el("font-size:26px;font-weight:600;margin:18px 0 6px;", S.unknownTitle));
    w.appendChild(Framey.el("font-size:17px;color:#7d8791;", S.unknownHint));
    unknown.forEach(addRow);
  }
  w.appendChild(Framey.button(S.reload, BTN_DIM, function () { st.status = null; st.games = null; draw(); }));

  w.appendChild(Framey.el("font-size:26px;font-weight:600;margin:18px 0 6px;", S.language));
  const langs = Framey.el("display:flex;flex-wrap:wrap;gap:8px;", "");
  CODES.forEach(function (c) {
    langs.appendChild(Framey.button(NAMES[c], c === lang ? BTN : BTN_DIM, function () {
      if (c !== lang) setLang(c, true);
    }));
  });
  w.appendChild(langs);

  w.appendChild(Framey.el("font-size:26px;font-weight:600;margin:18px 0 6px;", S.diagBtn));
  w.appendChild(Framey.el("font-size:17px;color:#7d8791;", S.diagHint));
  w.appendChild(Framey.button(S.diagBtn, BTN_DIM, function () {
    const d = steamDiag();
    d.lastFallbackReason = st.why || null;
    st.diag = d;
    draw();
    api("targets").then(function (r) {
      d.ports = (r && r.ports) || [];
      d.pages = ((r && r.targets) || []).map(function (t) { return t.port + " | " + t.title + " | " + t.url + (t.ws ? "" : " | no-ws"); });
    })
      .catch(function (e) { d.pages = String((e && e.message) || e); })
      .then(function () {
        return api("cdp_probe").then(function (r) { d.cdp = r; })
          .catch(function (e) { d.cdp = String((e && e.message) || e); });
      })
      .then(function () { if (root && !st.appid) draw(); });
  }));
  if (st.diag) {
    w.appendChild(Framey.el("font-family:monospace;font-size:15px;white-space:pre-wrap;word-break:break-all;background:#14181c;padding:10px;border-radius:8px;color:#c4ccd3;",
      JSON.stringify(st.diag, null, 1)));
  }
  return w;
}

// ---- detail ---------------------------------------------------------------

function select(appid, name, unknown) {
  st.appid = appid;
  st.localName = name || "";
  st.name = name || (S.unknownName + " · " + appid);
  st.unknown = !!unknown;
  st.mapped = null;
  st.srReq++;
  st.sr = { open: !!unknown, term: st.localName, results: null, used: "", loading: false, err: "" };
  st.kind = "grid_p";
  st.has = {};
  api("has", { appid: appid }).then(function (r) { st.has = r.has || {}; draw(); }).catch(function () {});
  switchKind("grid_p");
  if (st.sr.open && st.sr.term.trim().length >= 2) runSearch();
}

function switchKind(kind) {
  st.kind = kind;
  st.items = null;
  st.page = 0;
  st.more = false;
  st.listErr = "";
  if (st.unknown) { st.items = []; draw(); return; }   // SteamGridDB doesn't know this app: search by name first
  loadItems();
  draw();
}

function loadItems() {
  const token = ++st.req;
  const kind = st.kind;
  st.loading = true;
  api("list", { appid: st.appid, kind: kind, page: st.page }).then(function (r) {
    if (token !== st.req) return;
    st.items = (st.items || []).concat(r.items || []);
    st.more = !!r.more;
    st.listErr = "";
    st.mapped = r.mapped || null;
    if (st.page === 0 && !st.items.length && kind === "grid_p" && !st.mapped) offerSearch();
  }).catch(function (e) {
    if (token !== st.req) return;
    st.items = st.items || [];
    if (String((e && e.message) || e) === "not_found" && !st.mapped) {
      st.unknown = true;      // the backend has listed it under "Unknown" now
      st.dirtyHome = true;
      st.listErr = "";
      offerSearch();
    } else {
      st.listErr = errText(e);
    }
  }).then(function () {
    if (token !== st.req) return;
    st.loading = false;
    draw();
  });
}

// ---- applying artwork -----------------------------------------------------
// Steam's own call (the one Decky uses) sets artwork and refreshes the UI at once. Asset types
// follow Steam's grid file order: portrait 0, hero 1, logo 2, wide 3, icon 4.
// If the call is missing or fails, the image is written into the grid folder as a fallback
// (Steam then shows it after a restart).
const STEAM_TYPE = { grid_p: 0, hero: 1, logo: 2, grid_w: 3, icon: 4 };

function steamApps() {
  try { return (window.SteamClient && window.SteamClient.Apps) || null; } catch (e) { return null; }
}
function attempt(fn, ms) {
  return Promise.race([
    new Promise(function (res) { res(fn()); }),
    new Promise(function (_, rej) { setTimeout(function () { rej(new Error("timeout")); }, ms); }),
  ]);
}
function steamDiag() {
  const d = { steamClient: false, apps: false, setArtwork: false, clearArtwork: false, related: [] };
  try {
    const sc = window.SteamClient;
    const a = sc && sc.Apps;
    d.steamClient = !!sc;
    d.apps = !!a;
    if (a) {
      d.setArtwork = typeof a.SetCustomArtworkForApp === "function";
      d.clearArtwork = typeof a.ClearCustomArtworkForApp === "function";
      for (const k in a) { if (/artwork|custom|image|asset|icon/i.test(k) && d.related.length < 20) d.related.push(k); }
    }
  } catch (e) { d.error = String((e && e.message) || e); }
  try {
    const sc = window.SteamClient;
    if (sc) { d.clientKeys = []; for (const k in sc) { if (d.clientKeys.length < 40) d.clientKeys.push(k); } }
    d.globals = [];
    for (const k in window) { if (/store|library|artwork|overview/i.test(k) && d.globals.length < 25) d.globals.push(k); }
    d.page = String(document.title || "").slice(0, 60) + " | " + String(location.href || "").slice(0, 100);
  } catch (e) { d.error2 = String((e && e.message) || e); }
  return d;
}

function applyItem(it) {
  if (st.busy) return;
  st.busy = true;
  st.applyingKey = it.url;
  st.flash = null;
  Framey.toast(S.applying, 1500);
  const kind = st.kind, appid = st.appid;
  const apps = steamApps();
  const viaFile = function () {
    return api("apply", { appid: appid, kind: kind, url: it.url }).then(function () { Framey.toast(S.done, 6000); });
  };
  let job;
  if (kind === "icon") {
    // Icons are not set through Steam's artwork call; the backend writes them the way Steam stores icons
    job = api("icon_apply", { appid: appid, url: it.url }).then(function () { Framey.toast(S.done, 6000); });
  } else if (apps && typeof apps.SetCustomArtworkForApp === "function") {
    job = api("fetch", { url: it.url }).then(function (r) {
      return attempt(function () {
        // Steam ignores a new image while a custom one exists: clear the old one first.
        const pre = typeof apps.ClearCustomArtworkForApp === "function"
          ? Promise.resolve().then(function () { return apps.ClearCustomArtworkForApp(Number(appid), STEAM_TYPE[kind]); }).catch(function () {})
          : Promise.resolve();
        return pre.then(function () { return apps.SetCustomArtworkForApp(Number(appid), r.data, r.ext, STEAM_TYPE[kind]); });
      }, 20000);
    }).then(function () {
      Framey.toast(S.doneLive, 4000);
    }).catch(function (e) {
      st.why = String((e && e.message) || e);
      return viaFile();
    });
  } else {
    // This page (SteamVR's) has no SteamClient.Apps: let the backend call it in Steam's main page.
    st.why = "local SteamClient.Apps missing";
    job = api("cdp_apply", { appid: appid, kind: kind, url: it.url }).then(function () {
      Framey.toast(S.doneLive, 4000);
    }).catch(function (e) {
      st.why += " / cdp: " + String((e && e.message) || e);
      return viaFile();
    });
  }
  job.then(function () {
    st.has[kind] = true;
    st.flash = it.url;
    setTimeout(function () { if (st.flash === it.url) st.flash = null; }, 1800);
    const src = it._img && it._img.src;
    if (src && (kind === "icon" || (kind === "grid_p" && !iconCache[appid]))) iconCache[appid] = src;
  }).catch(function (e) {
    Framey.toast(S.failed + errText(e), 5000);
  }).then(function () {
    st.busy = false;
    st.applyingKey = null;
    draw();
  });
  draw();
}

function resetItem(appid, kind) {
  if (kind === "icon") return api("icon_reset", { appid: appid });
  const apps = steamApps();
  const live = apps && typeof apps.ClearCustomArtworkForApp === "function"
    ? attempt(function () { return apps.ClearCustomArtworkForApp(Number(appid), STEAM_TYPE[kind]); }, 10000).catch(function () {})
    : api("cdp_reset", { appid: appid, kind: kind }).catch(function () {});
  return live.then(function () { return api("reset", { appid: appid, kind: kind }); });
}

function tile(it) {
  const sz = SIZE[st.kind];
  const t = Framey.el("width:" + sz[0] + "px;cursor:pointer;", "");
  const wrap = Framey.el("position:relative;width:" + sz[0] + "px;height:" + sz[1] + "px;", "");
  const img = document.createElement("img");
  it._img = img;
  img.setAttribute("data-fy", "1");
  img.setAttribute("loading", "lazy");
  img.style.cssText = "display:block;width:" + sz[0] + "px;height:" + sz[1] +
    "px;object-fit:contain;background:#14181c;border-radius:10px;border:2px solid #3a434b;box-sizing:border-box;";
  img.onerror = function () {
    img.onerror = null;
    api("thumb", { url: it.thumb }).then(function (r) { img.src = r.data; }).catch(function () {});
  };
  img.src = it.thumb;
  wrap.appendChild(img);
  if (st.applyingKey === it.url) wrap.appendChild(overlay("busy"));
  else if (st.flash === it.url) { img.style.borderColor = "#2fb36b"; wrap.appendChild(overlay("done")); }
  t.appendChild(wrap);
  if (it.author) {
    t.appendChild(Framey.el("font-size:15px;color:#7d8791;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;", it.author));
  }
  t.onclick = function () { applyItem(it); };
  return t;
}

// ---- search by name -------------------------------------------------------

function offerSearch() {
  if (st.sr.open) return;
  st.sr.open = true;
  if (st.sr.term.trim().length >= 2 && st.sr.results === null) runSearch();
}

function runSearch() {
  const sr = st.sr, term = String(sr.term || "").trim();
  if (term.length < 2) return;
  const token = ++st.srReq;
  sr.loading = true;
  sr.err = "";
  draw();
  api("search", { term: term }).then(function (r) {
    if (token !== st.srReq) return;
    sr.results = r.results || [];
    sr.used = r.term || term;
  }).catch(function (e) {
    if (token !== st.srReq) return;
    sr.results = [];
    sr.err = errText(e);
  }).then(function () {
    if (token !== st.srReq) return;
    sr.loading = false;
    draw();
  });
}

function assignGame(g) {
  if (st.busy) return;
  st.busy = true;
  api("assign", { appid: st.appid, gid: g.id, name: g.name }).then(function () {
    st.unknown = false;
    st.mapped = { gid: g.id, name: g.name };
    st.dirtyHome = true;
    st.sr.open = false;
    st.sr.results = null;
    st.items = null;
    st.page = 0;
    st.listErr = "";
    Framey.toast(S.assigned, 2500);
    loadItems();
  }).catch(function (e) {
    Framey.toast(S.failed + errText(e), 4000);
  }).then(function () {
    st.busy = false;
    draw();
  });
}

function forgetMatch() {
  const wasUnknown = st.unknown;
  api("forget", { appid: st.appid }).then(function () {
    st.mapped = null;
    Framey.toast(S.forgotDone, 2500);
    if (wasUnknown) {            // removed from the "Unknown" list: back to the overview
      st.appid = null;
      st.req++;
      st.srReq++;
      st.status = null;
      st.games = null;
      st.dirtyHome = false;
      draw();
    } else {
      st.dirtyHome = true;
      st.sr.open = false;
      switchKind(st.kind);
    }
  }).catch(function (e) { Framey.toast(S.failed + errText(e), 4000); });
}

function searchPanel() {
  const sr = st.sr;
  const box = Framey.el("padding:14px 18px;margin:12px 0;border-radius:14px;background:#262c33;", "");
  box.appendChild(Framey.el("font-size:24px;font-weight:600;margin-bottom:4px;", S.searchTitle));
  if (st.unknown) box.appendChild(Framey.el("font-size:18px;color:#e6c34a;margin:4px 0;", S.err.not_found));
  box.appendChild(Framey.el("font-size:17px;color:#7d8791;", S.searchHint));
  const inp = field(S.searchPh);
  inp.value = sr.term;
  inp.oninput = function () { sr.term = inp.value; };
  box.appendChild(inp);
  const row = Framey.el("display:flex;flex-wrap:wrap;gap:8px;", "");
  row.appendChild(Framey.button(S.searchBtn, BTN, function () { sr.term = inp.value; runSearch(); }));
  if (!st.unknown) row.appendChild(Framey.button(S.hide, BTN_DIM, function () { st.srReq++; sr.open = false; sr.loading = false; draw(); }));
  if (st.unknown) row.appendChild(Framey.button(S.removeUnknown, BTN_DIM, forgetMatch));
  box.appendChild(row);
  if (sr.loading) box.appendChild(Framey.el("font-size:20px;color:#9aa5af;margin:8px 0;", S.searching));
  if (sr.err) box.appendChild(Framey.el("font-size:20px;color:#ff8a80;margin:8px 0;", sr.err));
  if (sr.results && !sr.loading) {
    if (!sr.results.length) {
      box.appendChild(Framey.el("font-size:20px;color:#9aa5af;margin:8px 0;", S.noMatches));
    } else {
      box.appendChild(Framey.el("font-size:22px;font-weight:600;margin:12px 0 4px;", S.suggestions));
      if (sr.used && sr.used.toLowerCase() !== String(sr.term).trim().toLowerCase()) {
        box.appendChild(Framey.el("font-size:16px;color:#7d8791;", S.searchedFor + ": " + sr.used));
      }
      sr.results.forEach(function (g) {
        const r = Framey.el("padding:14px 18px;margin:8px 0;border-radius:12px;background:#2a3138;font-size:22px;cursor:pointer;",
          (g.verified ? "✓ " : "") + g.name);
        r.onclick = function () { assignGame(g); };
        box.appendChild(r);
      });
    }
  }
  return box;
}

function detailView() {
  const w = Framey.el("padding:8px;color:#e6e9ec;");
  w.appendChild(Framey.button(S.back, BTN_DIM, function () {
    st.appid = null;
    st.req++;
    st.srReq++;
    st.loading = false;
    if (st.dirtyHome) { st.dirtyHome = false; st.status = null; st.games = null; }
    draw();
  }));
  const head = Framey.el("display:flex;align-items:center;gap:16px;margin:10px 0;", "");
  head.appendChild(iconEl(st.appid, 64, !!st.flash));
  head.appendChild(Framey.el("font-size:30px;font-weight:600;min-width:0;", st.name));
  w.appendChild(head);
  if (st.mapped) w.appendChild(Framey.el("font-size:18px;color:#9aa5af;", S.mappedTo + ": " + st.mapped.name));
  const acts = Framey.el("display:flex;flex-wrap:wrap;gap:8px;", "");
  if (!st.sr.open) {
    acts.appendChild(Framey.button(S.searchOther, BTN_DIM, function () {
      st.sr.open = true;
      if (!st.sr.term) st.sr.term = st.localName || (st.mapped ? st.mapped.name : "");
      draw();
    }));
  }
  if (st.mapped) acts.appendChild(Framey.button(S.forget, BTN_DIM, forgetMatch));
  if (acts.children.length) w.appendChild(acts);
  if (st.sr.open) w.appendChild(searchPanel());

  const tabs = Framey.el("display:flex;flex-wrap:wrap;gap:8px;margin:8px 0;", "");
  KINDS.forEach(function (k) {
    tabs.appendChild(Framey.button(S.kinds[k], k === st.kind ? BTN : BTN_DIM, function () {
      if (k !== st.kind) switchKind(k);
    }));
  });
  if (!st.unknown) w.appendChild(tabs);

  if (st.has[st.kind]) {
    const bar = Framey.el("display:flex;flex-wrap:wrap;align-items:center;gap:12px;margin:8px 0;", "");
    bar.appendChild(Framey.el("font-size:20px;color:#7fd18b;", S.custom));
    bar.appendChild(Framey.button(S.reset, BTN_DIM, function () {
      resetItem(st.appid, st.kind).then(function () {
        st.has[st.kind] = false;
        Framey.toast(S.resetDone, 2500);
        draw();
      }).catch(function (e) { Framey.toast(S.failed + errText(e), 4000); });
    }));
    w.appendChild(bar);
  }

  if (st.listErr) w.appendChild(Framey.el("font-size:22px;color:#ff8a80;margin:10px 0;", st.listErr));
  if (st.items === null) {
    w.appendChild(Framey.el("font-size:22px;color:#9aa5af;margin:10px 0;", S.loading));
    return w;
  }
  if (!st.items.length && !st.listErr && !st.unknown) w.appendChild(Framey.el("font-size:22px;color:#9aa5af;margin:10px 0;", S.empty));

  const grid = Framey.el("display:flex;flex-wrap:wrap;gap:14px;margin:12px 0;", "");
  st.items.forEach(function (it) { grid.appendChild(tile(it)); });
  w.appendChild(grid);

  if (st.more) {
    w.appendChild(Framey.button(st.loading ? S.loading : S.more, BTN_DIM, function () {
      if (st.loading) return;
      st.page++;
      loadItems();
      draw();
    }));
  }
  return w;
}

Framey.register({
  name: "SteamGridDB",
  short: "SGDB",
  render: function (box) {
    root = box;
    st.appid = null;
    st.req++;
    st.loading = false;
    draw();
  },
});
